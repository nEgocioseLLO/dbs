#!/bin/bash
pwd
ls
